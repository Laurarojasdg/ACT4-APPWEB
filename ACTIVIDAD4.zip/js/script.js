

function nombrePreguntaPsicología() {

    var nombrePreguntaPsicología = prompt("Juegos de rol:Ayudan a los niños a comprender las emociones y situaciones ajenas.")

if (nombrePreguntaPsicología == "verdadero") {
    alert("La respuesta es correcta");
} else {
    alert("La respuesta es incorrecta");
}
    
}


function nombrePreguntaNeuropsicología() {

    var nombrePreguntaNeuropsicología = prompt("Dinámicas de compartir:Estimulan la interacción social y la actividad física.")

if (nombrePreguntaNeuropsicología == "falso") {
    alert("La respuesta es correcta");
} else {
    alert("La respuesta es incorrecta");
}
    
}

function nombrePreguntaSensopercepción() {

    var nombrePreguntaSensopercepción = prompt("Teatro en grupo:Ayuda a los niños a mejorar la expresión y el trabajo en grupo")

if (nombrePreguntaSensopercepción == "verdadero") {
    alert("La respuesta es correcta");
} else {
    alert("La respuesta es incorrecta");
}
    
}
